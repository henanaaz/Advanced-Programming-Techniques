/*
Author: Hena Naaz
Class: ECE6122 A
Last Date Modified: 11 September 2022
Description: Lab 0 Problem 1
What is the purpose of this file?
Purpose:to print the following using insertion operator and escape sequences
	"My name is: (your first and last name separated by a space)
	This (�) is a double quote.
	This (�) is a single quote.
	This (\) is a backslash.
	This (/) is a forward slash."
*/

#include <iostream>

using namespace std;

int main()
{
	cout << "My name is: Hena Naaz\n";
	cout << "This (\") is a double quote.\n";
	cout << "This (\') is a single quote.\n";
	cout << "This (\\) is a backlash.\n";
	cout << "This (/) is a forward slash.\n";
}